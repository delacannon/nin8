// OPNA AudioWorklet Processor
// Runs YM2608 emulation via WASM in the audio thread

class OPNAProcessor extends AudioWorkletProcessor {
  constructor() {
    super()

    this.wasmReady = false
    this.testMode = false
    this.wasmModule = null
    this.wasmExports = null

    // Sample rate conversion state
    this.nativeRate = 55556
    this.outputRate = sampleRate
    this.accumulator = 0
    this.lastSampleL = 0
    this.lastSampleR = 0
    this.prevSampleL = 0
    this.prevSampleR = 0

    // Test mode state - 6 voice polyphony
    this.algorithm = 4
    this.feedback = 5
    this.opMul = [2, 2, 2, 1] // OP1-4 frequency multipliers (0=0.5, 1-15=×n)
    this.opDT = [7, 3, 3, 0]  // OP1-4 detune (0-7)
    this.opTL = [20, 4, 18, 0] // OP1-4 total levels (0=max, 127=silent)

    // Detune table: pitch multiplier for each DT value
    // DT 0-3: positive detune, 4: none, 5-7: negative detune
    this.dtTable = [0, 0.015, 0.03, 0.045, 0, -0.045, -0.03, -0.015]

    // LFO state
    this.lfoPhase = 0
    this.lfoFreq = 0   // 0-7 index
    this.ams = 0       // 0-3 amplitude mod sensitivity
    this.pms = 0       // 0-7 phase mod sensitivity
    this.opAM = [0, 0, 0, 0]  // AM enable per operator

    // SSG-EG per operator (0-15, 0-7=off, 8+=enabled)
    this.opSsgEg = [0, 0, 0, 0]

    // Key Scaling per operator (0-3)
    this.opKS = [0, 0, 0, 0]

    // Sample-accurate event scheduling
    this.eventQueue = []      // { sampleTime: number, event: object }[]
    this.currentSample = 0    // Global sample counter
    this.isPlaying = false    // Whether sequencer is playing

    // Stereo pan (0=mute, 1=L, 2=R, 3=center)
    this.pan = 3

    // LFO frequency table (Hz)
    this.lfoFreqTable = [3.98, 5.56, 6.02, 6.37, 6.88, 9.63, 48.1, 72.2]

    // AMS depth table: 0, 1.4, 5.9, 11.8 dB → linear attenuation factor
    // Formula: 1 - 10^(-dB/20)
    this.amsDepthTable = [0, 0.148, 0.507, 0.743]

    // PMS depth table: 0, 3.4, 6.7, 10, 14, 20, 40, 80 cents → frequency ratio
    // Formula: 2^(cents/1200) - 1
    this.pmsDepthTable = [0, 0.00197, 0.00388, 0.00579, 0.00813, 0.01163, 0.02337, 0.04729]

    // Feedback radians table: YM2608 feedback 0-7 (reduced from original for less harshness)
    this.fbRadians = [0, Math.PI/32, Math.PI/16, Math.PI/8, Math.PI/4, Math.PI/2, Math.PI, Math.PI*2]

    // ADSR per operator (shared across voices)
    this.opAdsr = [
      { ar: 31, dr: 8, sr: 0, sl: 12, rr: 7, tl: 20, mul: 2, dt: 7 },
      { ar: 31, dr: 5, sr: 2, sl: 6, rr: 7, tl: 4, mul: 2, dt: 3 },
      { ar: 31, dr: 7, sr: 4, sl: 10, rr: 7, tl: 18, mul: 2, dt: 3 },
      { ar: 31, dr: 0, sr: 4, sl: 0, rr: 7, tl: 0, mul: 1, dt: 0 },
    ]

    // 6 voices for polyphony
    this.voices = []
    for (let v = 0; v < 6; v++) {
      this.voices.push({
        note: null,
        freq: 0,
        opPhase: [0, 0, 0, 0],
        opEnvLevel: [0, 0, 0, 0],
        opEnvStage: ['off', 'off', 'off', 'off'],
        opSsgDir: [1, 1, 1, 1],  // SSG-EG direction: 1=rising, -1=falling
        opSsgHeld: [false, false, false, false], // SSG-EG held state
        op1Prev: 0, // Previous OP1 output for feedback
        op1Prev2: 0, // Second previous OP1 output (YMFM uses 2-sample avg)
      })
    }

    this.port.onmessage = this.handleMessage.bind(this)
  }

  async handleMessage(event) {
    const { type, wasmBytes, port, addr, data, note } = event.data

    if (type === 'init') {
      if (!wasmBytes) {
        console.warn('No WASM bytes provided, using test mode')
        this.testMode = true
        this.port.postMessage({ type: 'ready', testMode: true })
        return
      }

      try {
        // Direct WASM instantiation - bypassing Emscripten glue code
        // Emscripten uses module "a" for imports with functions a, b, c
        const imports = {
          a: {
            a: (cond, file, line, func) => { console.error('assert failed') },  // __assert_fail
            b: () => { console.error('abort') },                                  // __abort_js
            c: (size) => { console.error('OOM:', size); return 0 },              // _emscripten_resize_heap
          },
        }

        const result = await WebAssembly.instantiate(wasmBytes, imports)
        const exports = result.instance.exports

        // Memory is exported as 'd'
        this.wasmMemory = exports.d

        // Store exports - Emscripten uses single-letter exports
        // Order matches build.sh EXPORTED_FUNCTIONS: init,reset,write,generate,sample_rate,
        // load_rhythm_rom,get_rhythm_rom_ptr,has_rhythm_rom,get_adpcm_b_ptr,has_adpcm_b,get_adpcm_b_size,malloc,free
        this.wasmExports = {
          _ym2608_init: exports.f,
          _ym2608_reset: exports.g,
          _ym2608_write: exports.h,
          _ym2608_generate: exports.i,
          _ym2608_sample_rate: exports.j,
          // ADPCM-A functions
          _ym2608_load_rhythm_rom: exports.k,
          _ym2608_get_rhythm_rom_ptr: exports.l,
          _ym2608_has_rhythm_rom: exports.m,
          // ADPCM-B functions
          _ym2608_get_adpcm_b_ptr: exports.n,
          _ym2608_has_adpcm_b: exports.o,
          _ym2608_get_adpcm_b_size: exports.p,
          // Memory allocation
          _malloc: exports.q,
          _free: exports.r,
          getValue: (ptr) => {
            const heap = new Int32Array(this.wasmMemory.buffer)
            return heap[ptr >> 2]
          },
          writeBytes: (ptr, data) => {
            const heap = new Uint8Array(this.wasmMemory.buffer)
            heap.set(data, ptr)
          },
        }

        this.initWasm()
      } catch (e) {
        console.warn('WASM init failed, using test mode:', e.message, e)
        this.testMode = true
        this.port.postMessage({ type: 'ready', testMode: true })
      }
    } else if (type === 'write') {
      if (this.wasmReady) {
        this.wasmExports._ym2608_write(port, addr, data)
      }
    } else if (type === 'noteOn' && this.testMode) {
      // Find free voice or steal one
      let voice = this.voices.find(v => v.note === null)
      if (!voice) {
        // Steal first voice (could improve with LRU)
        voice = this.voices[0]
      }
      voice.note = note
      voice.freq = this.noteToFreq(note)
      // Reset phases and start envelopes
      for (let i = 0; i < 4; i++) {
        voice.opPhase[i] = 0
        voice.opEnvStage[i] = 'attack'
        voice.opEnvLevel[i] = 0
        // Reset SSG-EG state based on mode
        const ssgEg = this.opSsgEg[i]
        if (ssgEg >= 8) {
          // Bit 2: initial direction (0=decay starts high, 1=attack starts low)
          voice.opSsgDir[i] = (ssgEg & 0x04) ? 1 : -1
          voice.opEnvLevel[i] = (ssgEg & 0x04) ? 0 : 1
        } else {
          voice.opSsgDir[i] = 1
        }
        voice.opSsgHeld[i] = false
      }
    } else if (type === 'noteOff' && this.testMode) {
      // Find voice playing this note
      const voice = this.voices.find(v => v.note === note)
      if (voice) {
        voice.note = null // Mark as released
        for (let i = 0; i < 4; i++) {
          voice.opEnvStage[i] = 'release'
        }
      }
    } else if (type === 'setEnvelope' && this.testMode) {
      const { opIndex, envelope } = event.data
      if (opIndex >= 0 && opIndex < 4) {
        this.opAdsr[opIndex] = { ...envelope }
        // Validate and clamp all parameters to valid ranges
        this.opTL[opIndex] = Math.max(0, Math.min(127, envelope.tl ?? 0))
        this.opMul[opIndex] = Math.max(0, Math.min(15, envelope.mul ?? 1))
        this.opDT[opIndex] = Math.max(0, Math.min(7, envelope.dt ?? 0))
        this.opAM[opIndex] = envelope.am ? 1 : 0
        this.opSsgEg[opIndex] = Math.max(0, Math.min(15, envelope.ssgEg ?? 0))
        this.opKS[opIndex] = Math.max(0, Math.min(3, envelope.ks ?? 0))
      }
    } else if (type === 'setAlgorithm' && this.testMode) {
      this.algorithm = Math.max(0, Math.min(7, event.data.algorithm ?? 0))
    } else if (type === 'setFeedback' && this.testMode) {
      this.feedback = Math.max(0, Math.min(7, event.data.feedback ?? 0))
    } else if (type === 'setLFO' && this.testMode) {
      const { freq, ams, pms } = event.data
      this.lfoFreq = freq ?? 0
      this.ams = ams ?? 0
      this.pms = pms ?? 0
    } else if (type === 'setPan' && this.testMode) {
      this.pan = event.data.pan ?? 3
    } else if (type === 'loadRhythmRom') {
      // Load ADPCM-A rhythm ROM data into WASM
      const { romData } = event.data
      if (this.wasmReady && romData && romData.length > 0) {
        try {
          const ptr = this.wasmExports._ym2608_get_rhythm_rom_ptr(romData.length)
          if (ptr) {
            this.wasmExports.writeBytes(ptr, romData)
            console.log('OPNA: Loaded rhythm ROM, size:', romData.length)
            this.port.postMessage({ type: 'rhythmRomLoaded', success: true })
          } else {
            this.port.postMessage({ type: 'rhythmRomLoaded', success: false })
          }
        } catch (e) {
          console.error('OPNA: Error loading rhythm ROM:', e)
          this.port.postMessage({ type: 'rhythmRomLoaded', success: false })
        }
      }
    } else if (type === 'loadAdpcmB') {
      // Load ADPCM-B sample data into WASM
      const { sampleData, offset } = event.data
      if (this.wasmReady && sampleData && sampleData.length > 0) {
        try {
          // Allocate or get existing ADPCM-B RAM buffer
          const totalSize = offset + sampleData.length
          const ptr = this.wasmExports._ym2608_get_adpcm_b_ptr(totalSize)
          if (ptr) {
            // Write sample data at offset
            this.wasmExports.writeBytes(ptr + offset, sampleData)
            console.log('OPNA: Loaded ADPCM-B sample at offset', offset, 'size:', sampleData.length)
            this.port.postMessage({ type: 'adpcmBLoaded', success: true })
          } else {
            this.port.postMessage({ type: 'adpcmBLoaded', success: false })
          }
        } catch (e) {
          console.error('OPNA: Error loading ADPCM-B:', e)
          this.port.postMessage({ type: 'adpcmBLoaded', success: false })
        }
      }
    } else if (type === 'reset') {
      if (this.wasmReady) {
        this.wasmExports._ym2608_reset()
      }
    } else if (type === 'scheduleEvents') {
      // Sample-accurate event scheduling
      // Reset sample counter and clear queue for fresh scheduling
      this.currentSample = 0
      this.eventQueue = []
      const { events } = event.data
      for (const evt of events) {
        // Convert time (seconds) to sample position (from 0)
        const sampleTime = Math.floor(evt.time * sampleRate)
        this.eventQueue.push({ sampleTime, event: evt })
      }
      // Keep queue sorted by time
      this.eventQueue.sort((a, b) => a.sampleTime - b.sampleTime)
      this.isPlaying = true
    } else if (type === 'clearEvents') {
      // Stop playback and clear queue
      this.eventQueue = []
      this.currentSample = 0
      this.isPlaying = false
    } else if (type === 'startPlayback') {
      // Reset sample counter for new playback
      this.currentSample = 0
      this.isPlaying = true
    } else if (type === 'stopPlayback') {
      this.isPlaying = false
    }
  }

  noteToFreq(note) {
    const match = note.match(/^([A-G]#?)(\d)$/)
    if (!match) return 440

    const noteNames = { C: 0, 'C#': 1, D: 2, 'D#': 3, E: 4, F: 5, 'F#': 6, G: 7, 'G#': 8, A: 9, 'A#': 10, B: 11 }
    const semitone = noteNames[match[1]] || 0
    const octave = parseInt(match[2], 10)

    const semitonesFromA4 = semitone - 9 + (octave - 4) * 12
    return 440 * Math.pow(2, semitonesFromA4 / 12)
  }

  initWasm() {
    const exports = this.wasmExports
    exports._ym2608_init()
    const clock = 8000000
    this.nativeRate = exports._ym2608_sample_rate(clock)
    console.log('YM2608 native sample rate:', this.nativeRate, 'output:', sampleRate)
    this.wasmReady = true
    this.port.postMessage({ type: 'ready', testMode: false })
  }

  // Execute a scheduled event (register write)
  executeScheduledEvent(evt) {
    if (!this.wasmReady) return

    if (evt.type === 'write') {
      this.wasmExports._ym2608_write(evt.port, evt.addr, evt.data)
    }
  }

  process(_inputs, outputs, _parameters) {
    const output = outputs[0]
    if (!output || output.length === 0) return true

    const left = output[0]
    const right = output[1] || left

    if (this.testMode) {
      this.processTestMode(left, right)
      return true
    }

    if (!this.wasmReady) {
      left.fill(0)
      if (right !== left) right.fill(0)
      return true
    }

    const exports = this.wasmExports
    const ratio = this.nativeRate / this.outputRate

    for (let i = 0; i < left.length; i++) {
      // Execute any scheduled events at this sample
      if (this.isPlaying) {
        while (this.eventQueue.length > 0 &&
               this.eventQueue[0].sampleTime <= this.currentSample) {
          const { event: evt } = this.eventQueue.shift()
          this.executeScheduledEvent(evt)
        }
      }

      this.accumulator += ratio
      while (this.accumulator >= 1) {
        // Store previous samples for interpolation
        this.prevSampleL = this.lastSampleL
        this.prevSampleR = this.lastSampleR
        const bufPtr = exports._ym2608_generate(1)
        if (bufPtr) {
          this.lastSampleL = exports.getValue(bufPtr, 'i32')
          this.lastSampleR = exports.getValue(bufPtr + 4, 'i32')
        }
        this.accumulator -= 1
      }
      // Linear interpolation between prev and current samples
      const t = this.accumulator // fractional position 0-1
      // Scale YMFM output to -1..1 (16-bit range with headroom)
      const scale = 1.0 / 24576 // ~-3dB below 32768 for headroom
      left[i] = ((1 - t) * this.prevSampleL + t * this.lastSampleL) * scale
      right[i] = ((1 - t) * this.prevSampleR + t * this.lastSampleR) * scale

      // Advance sample counter
      if (this.isPlaying) {
        this.currentSample++
      }
    }

    return true
  }

  // Update envelope for one operator of a voice
  updateOpEnvelope(voice, op) {
    const adsr = this.opAdsr[op]
    const ssgEg = this.opSsgEg[op]
    const ks = this.opKS[op]

    // YM2608 envelope timing - log interpolation between extremes
    // Rate 31 = 2ms (instant), Rate 0 = 8 seconds
    const rateToTime = (rate) => {
      if (rate >= 31) return 0.002 // 2ms instant
      if (rate <= 0) return 8.0 // 8 seconds
      // Smooth exponential curve from 8s to 2ms
      const t = rate / 31
      return 8.0 * Math.pow(0.002 / 8.0, t)
    }

    // Calculate rates as change-per-sample
    let attackRate = 1 / (rateToTime(adsr.ar) * sampleRate)
    let decayRate = 1 / (rateToTime(adsr.dr) * sampleRate)
    // SR=0 means no sustain decay (holds indefinitely)
    let sustainRate = adsr.sr > 0 ? 1 / (rateToTime(adsr.sr) * sampleRate) : 0
    // RR 0-15: scale to 0-31 range (×2+1)
    let releaseRate = 1 / (rateToTime(adsr.rr * 2 + 1) * sampleRate)

    // Sustain level: 0=max (1.0), 15=min - using full 48dB range
    const sustainLevel = Math.pow(10, -(adsr.sl / 15) * 48 / 20)
    // NaN protection: ensure rates have minimum value
    attackRate = Math.max(attackRate, 0.00001)
    decayRate = Math.max(decayRate, 0.00001)
    releaseRate = Math.max(releaseRate, 0.00001)

    // Apply Key Scaling: higher notes = faster envelope rates
    // Minimum 20Hz to avoid log2 issues with very low frequencies
    if (ks > 0 && voice.freq >= 20) {
      const octave = Math.max(0, Math.floor(Math.log2(voice.freq / 261.63))) // C4 = octave 0
      const ksMultiplier = 1 + (ks * octave * 0.2)
      attackRate *= ksMultiplier
      decayRate *= ksMultiplier
      sustainRate *= ksMultiplier
      releaseRate *= ksMultiplier
    }

    // SSG-EG mode: use simplified envelope with looping/holding
    if (ssgEg >= 8 && voice.opEnvStage[op] !== 'release' && voice.opEnvStage[op] !== 'off') {
      if (voice.opSsgHeld[op]) return // Held at boundary

      const alternate = (ssgEg & 0x02) !== 0
      const hold = (ssgEg & 0x01) !== 0

      // Use decay rate for SSG-EG cycling
      voice.opEnvLevel[op] += voice.opSsgDir[op] * decayRate

      // Check boundaries
      if (voice.opEnvLevel[op] >= 1) {
        voice.opEnvLevel[op] = 1
        if (hold && voice.opSsgDir[op] > 0) {
          voice.opSsgHeld[op] = true
        } else if (alternate) {
          voice.opSsgDir[op] = -1 // Reverse direction
        } else {
          voice.opEnvLevel[op] = 0 // Reset to start
        }
      } else if (voice.opEnvLevel[op] <= 0) {
        voice.opEnvLevel[op] = 0
        if (hold && voice.opSsgDir[op] < 0) {
          voice.opSsgHeld[op] = true
        } else if (alternate) {
          voice.opSsgDir[op] = 1 // Reverse direction
        } else {
          voice.opEnvLevel[op] = 1 // Reset to start
        }
      }
      return
    }

    // Normal ADSR envelope
    switch (voice.opEnvStage[op]) {
      case 'attack':
        voice.opEnvLevel[op] += attackRate
        if (voice.opEnvLevel[op] >= 1) {
          voice.opEnvLevel[op] = 1
          voice.opEnvStage[op] = 'decay'
        }
        break
      case 'decay':
        voice.opEnvLevel[op] -= decayRate
        if (voice.opEnvLevel[op] <= sustainLevel) {
          voice.opEnvLevel[op] = sustainLevel
          voice.opEnvStage[op] = 'sustain'
        }
        break
      case 'sustain':
        voice.opEnvLevel[op] -= sustainRate
        if (voice.opEnvLevel[op] < 0) voice.opEnvLevel[op] = 0
        break
      case 'release':
        voice.opEnvLevel[op] -= releaseRate
        if (voice.opEnvLevel[op] <= 0) {
          voice.opEnvLevel[op] = 0
          voice.opEnvStage[op] = 'off'
        }
        break
      default:
        voice.opEnvLevel[op] = 0
    }
    // NaN guard: reset to 0 if envelope becomes invalid
    if (!Number.isFinite(voice.opEnvLevel[op])) {
      voice.opEnvLevel[op] = 0
    }
  }

  // Generate operator output for a voice
  genOp(voice, op, modulation = 0, lfoAM = 0) {
    let env = voice.opEnvLevel[op]
    // NaN guard: catches both NaN and <= 0
    if (!(env > 0)) return 0
    // Apply LFO amplitude modulation if AM enabled for this op
    if (this.opAM[op] && lfoAM > 0) {
      env *= (1 - lfoAM)
    }
    // Apply Total Level attenuation (0=max, 127=silent) with dB curve
    const tlDb = (this.opTL[op] / 127) * 48 // 0-48dB range
    const tlAtten = Math.pow(10, -tlDb / 20)
    // Generate sine with modulation (no arbitrary scaling)
    const raw = Math.sin(voice.opPhase[op] + modulation) * env * tlAtten
    // Hard clip to ±1 range to prevent distortion
    return Math.max(-1, Math.min(1, raw))
  }

  // Generate sample for one voice
  genVoiceSample(voice, lfoAM) {
    const op = [0, 0, 0, 0]
    // Feedback: YMFM averages 2 previous samples, then applies shift-based scaling
    // fb=0: no feedback, fb=7: max feedback (shift by 3)
    const fbAvg = (voice.op1Prev + voice.op1Prev2) * 0.5
    const fbMod = this.feedback > 0 ? fbAvg * this.fbRadians[this.feedback] : 0

    // YMFM divides modulation by 2 before applying (opmod >> 1)
    // All modulation values are halved to match hardware behavior
    switch (this.algorithm) {
      case 0: // 1→2→3→4
        op[0] = this.genOp(voice, 0, fbMod, lfoAM)
        op[1] = this.genOp(voice, 1, op[0] * 0.5, lfoAM)
        op[2] = this.genOp(voice, 2, op[1] * 0.5, lfoAM)
        op[3] = this.genOp(voice, 3, op[2] * 0.5, lfoAM)
        voice.op1Prev2 = voice.op1Prev
        voice.op1Prev = op[0]
        return op[3]
      case 1: // (1+2)→3→4
        op[0] = this.genOp(voice, 0, fbMod, lfoAM)
        op[1] = this.genOp(voice, 1, 0, lfoAM)
        op[2] = this.genOp(voice, 2, (op[0] + op[1]) * 0.5, lfoAM)
        op[3] = this.genOp(voice, 3, op[2] * 0.5, lfoAM)
        voice.op1Prev2 = voice.op1Prev
        voice.op1Prev = op[0]
        return op[3]
      case 2: // (1+(2→3))→4
        op[0] = this.genOp(voice, 0, fbMod, lfoAM)
        op[1] = this.genOp(voice, 1, 0, lfoAM)
        op[2] = this.genOp(voice, 2, op[1] * 0.5, lfoAM)
        op[3] = this.genOp(voice, 3, (op[0] + op[2]) * 0.5, lfoAM)
        voice.op1Prev2 = voice.op1Prev
        voice.op1Prev = op[0]
        return op[3]
      case 3: // ((1→2)+3)→4
        op[0] = this.genOp(voice, 0, fbMod, lfoAM)
        op[1] = this.genOp(voice, 1, op[0] * 0.5, lfoAM)
        op[2] = this.genOp(voice, 2, 0, lfoAM)
        op[3] = this.genOp(voice, 3, (op[1] + op[2]) * 0.5, lfoAM)
        voice.op1Prev2 = voice.op1Prev
        voice.op1Prev = op[0]
        return op[3]
      case 4: // (1→2)+(3→4)
        op[0] = this.genOp(voice, 0, fbMod, lfoAM)
        op[1] = this.genOp(voice, 1, op[0] * 0.5, lfoAM)
        op[2] = this.genOp(voice, 2, 0, lfoAM)
        op[3] = this.genOp(voice, 3, op[2] * 0.5, lfoAM)
        voice.op1Prev2 = voice.op1Prev
        voice.op1Prev = op[0]
        return op[1] + op[3]
      case 5: // 1→(2+3+4)
        op[0] = this.genOp(voice, 0, fbMod, lfoAM)
        op[1] = this.genOp(voice, 1, op[0] * 0.5, lfoAM)
        op[2] = this.genOp(voice, 2, op[0] * 0.5, lfoAM)
        op[3] = this.genOp(voice, 3, op[0] * 0.5, lfoAM)
        voice.op1Prev2 = voice.op1Prev
        voice.op1Prev = op[0]
        return op[1] + op[2] + op[3]
      case 6: // (1→2)+3+4
        op[0] = this.genOp(voice, 0, fbMod, lfoAM)
        op[1] = this.genOp(voice, 1, op[0] * 0.5, lfoAM)
        op[2] = this.genOp(voice, 2, 0, lfoAM)
        op[3] = this.genOp(voice, 3, 0, lfoAM)
        voice.op1Prev2 = voice.op1Prev
        voice.op1Prev = op[0]
        return op[1] + op[2] + op[3]
      case 7: // 1+2+3+4 (all carriers)
        op[0] = this.genOp(voice, 0, fbMod, lfoAM)
        op[1] = this.genOp(voice, 1, 0, lfoAM)
        op[2] = this.genOp(voice, 2, 0, lfoAM)
        op[3] = this.genOp(voice, 3, 0, lfoAM)
        voice.op1Prev2 = voice.op1Prev
        voice.op1Prev = op[0]
        return op[0] + op[1] + op[2] + op[3]
      default:
        return 0
    }
  }

  processTestMode(left, right) {
    const twoPi = 2 * Math.PI
    // Bounds-checked table lookups
    const lfoIdx = Math.max(0, Math.min(7, this.lfoFreq))
    const lfoHz = this.lfoFreqTable[lfoIdx] || 3.98
    const lfoIncr = (twoPi * lfoHz) / sampleRate
    const amsIdx = Math.max(0, Math.min(3, this.ams))
    const pmsIdx = Math.max(0, Math.min(7, this.pms))
    const amsDepth = this.amsDepthTable[amsIdx] || 0
    const pmsDepth = this.pmsDepthTable[pmsIdx] || 0

    for (let i = 0; i < left.length; i++) {
      // Calculate LFO using triangle wave (YM2608 uses triangle, not sine)
      const lfoPhaseNorm = this.lfoPhase / twoPi // 0-1
      const lfoTriangle = 1 - 4 * Math.abs(lfoPhaseNorm - 0.5) // -1 to 1
      const lfoAM = (lfoTriangle + 1) * 0.5 * amsDepth  // 0 to amsDepth
      const lfoPM = lfoTriangle * pmsDepth  // -pmsDepth to +pmsDepth

      let totalSample = 0

      // Process all voices
      for (const voice of this.voices) {
        // Update envelopes
        for (let op = 0; op < 4; op++) {
          this.updateOpEnvelope(voice, op)
        }

        // Check if voice is active
        const anyActive = voice.opEnvLevel.some(e => e > 0)
        if (!anyActive) continue

        // Generate and sum voice output with LFO AM
        totalSample += this.genVoiceSample(voice, lfoAM)

        // Advance phases with MUL, DT, and LFO PM
        for (let op = 0; op < 4; op++) {
          // MUL: 0=×0.5, 1-15=×n
          const mul = this.opMul[op] === 0 ? 0.5 : this.opMul[op]
          // DT: apply detune offset with bounds check
          const dtIdx = Math.max(0, Math.min(7, this.opDT[op]))
          const dtOffset = 1 + (this.dtTable[dtIdx] ?? 0)
          // Apply PMS (vibrato) to frequency
          const pmOffset = 1 + lfoPM
          const freq = voice.freq * mul * dtOffset * pmOffset
          // Clamp phase increment to prevent aliasing at very high frequencies
          const phaseInc = Math.min((twoPi * freq) / sampleRate, Math.PI)
          voice.opPhase[op] = (voice.opPhase[op] + phaseInc) % twoPi
        }
      }

      // Advance LFO phase using modulo for smooth wrap
      this.lfoPhase = (this.lfoPhase + lfoIncr) % twoPi

      // Normalize output and apply stereo pan
      totalSample *= 0.15
      const panL = (this.pan & 1) ? 1 : 0  // Bit 0 = left enable
      const panR = (this.pan & 2) ? 1 : 0  // Bit 1 = right enable
      left[i] = totalSample * panL
      right[i] = totalSample * panR
    }
  }
}

registerProcessor('opna-processor', OPNAProcessor)
